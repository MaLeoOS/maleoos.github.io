module.exports = {
  semi: true,
  trailingComma: 'none',
  singleQuote: true,
  tabWidth: 2,
  printWidth: 120
};
